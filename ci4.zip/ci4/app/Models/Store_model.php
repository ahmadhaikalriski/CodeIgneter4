<?php

namespace App\Models;

use CodeIgniter\Model;

class Store_model extends Model
{

    public function getStore()
    {
        $builder = $this->db->table('stores');
        $builder->select('*');
        return $builder->get();
    }

    public function saveStore($data)
    {
        $query = $this->db->table('stores')->insert($data);
        return $query;
    }

    public function editStore($id)
    {
        $builder = $this->db->table('stores');
        $builder->select('*');
        $builder->where('id_store', $id);
        $query = $builder->get();
        return $query;
    }

    public function updateStore($data, $id)
    {
        $query = $this->db->table('stores')->update($data, array('id_store' => $id));
        return $query;
    }

    public function deleteStore($id)
    {
        $query = $this->db->table('stores')->delete(array('id_store' => $id));
        return $query;
    }
}
